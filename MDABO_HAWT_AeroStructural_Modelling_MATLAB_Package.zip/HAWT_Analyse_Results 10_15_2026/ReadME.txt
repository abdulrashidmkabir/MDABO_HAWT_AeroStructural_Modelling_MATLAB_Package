%%  The main function file is the "RUN_Update_MB.m".
%  Simply run the main file and wait while the software simulates scenarios 
%  of HAWT Design and update the Model Bank (MB.m)

%% The following files/Folders are included.
                  
Model Bank (Data Storage)          
1.  MB.mat                        

Folder of Airfoil Data Bank                      
1.  S814_825_826_interpolated_38               
2.  Standard profiles             
                      
Executable Java XFOIL Software Packages    
1.  xfoil.exe  
2.  @Airfoil                      
3.  @XFOIL 

MATLAB Function/sub-Function files
1.  Design_HAWT_Blade.m 
2.  XFoil_launcher.m             
3.  Input_data.m   
4.  RUN_Update_MB.m   (Main Function)
5.  aeroChord.m                   
6.  aeroTwist.m                   
7.  chordFilter.m                 
8.  gerAirfoilCoords.m            
9.  getBladeInfos.m               
10. get_airfoil_names.m
11. SampleInput.m   
                  