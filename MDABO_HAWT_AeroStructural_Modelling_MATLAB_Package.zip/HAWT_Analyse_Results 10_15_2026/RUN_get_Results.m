global Aero_Results
col={'g','m','r','k','y','b'};
shp={'->g','-<m','-^r','-ok','-sy','-xb'};
Lgd={'Case-1','Case-2','Case-3','Case-4','Case-5','Case-6'};
Aero_Results=struct;
Aero_Results.R=[];
Aero_Results.L=[];
Aero_Results.T=[];
Aero_Results.CL=[];
Aero_Results.CD=[];
Aero_Results.CP=[];
Aero_Results.Re=[];
Aero_Results.PD=[];
Aero_Results.OF=[];
Aero_Results.LDR=[];

Result='MB.mat';
Cases=who('-file',Result);
Cases=Cases(2:end,:);
nd_y=fix(numel(Cases)/6);
Cases=Cases(1:6*nd_y,1);
Cases=reshape(Cases,6,nd_y);
CASE1=Cases(:,1:2:end);
CASE2=Cases(:,2:2:end);
for Case=1:size(CASE1,2)
    for Obj=1:6
        c=CASE1{Obj,Case};
        CASE1{Obj,Case}=load(Result,c);
        CASE1{Obj,Case}=CASE1{Obj,Case}.(c);
    end
end
for Case=1:size(CASE2,2)
    for Obj=1:6
        c=CASE2{Obj,Case};
        CASE2{Obj,Case}=load(Result,c);
        CASE2{Obj,Case}=CASE2{Obj,Case}.(c);
    end
end
Organize_and_Plot_Results(1,CASE1,CASE2,0)
Organize_and_Plot_Results(2,CASE1,CASE2,0)
Organize_and_Plot_Results(3,CASE1,CASE2,0)
Organize_and_Plot_Results(4,CASE1,CASE2,0)
Organize_and_Plot_Results(5,CASE1,CASE2,0)
Organize_and_Plot_Results(6,CASE1,CASE2,1)
Result=matfile('MB.mat','Writable',true);
Result.Aero_Results=Aero_Results;
matfile('MB.mat','Writable',false);

for i=1:numel(Aero_Results.OF)
    Pd=Aero_Results.CP{i};
    ID_Best(i)=find(sum(Pd)==max(sum(Pd)),1);
    L(:,i)=Aero_Results.L{i}(:,ID_Best(i));
    T(:,i)=Aero_Results.T{i}(:,ID_Best(i));
    CL(:,i)=Aero_Results.CL{i}(:,ID_Best(i));
    CD(:,i)=Aero_Results.CD{i}(:,ID_Best(i));
    CP(:,i)=Aero_Results.CP{i}(:,ID_Best(i));
    Re(:,i)=Aero_Results.Re{i}(:,ID_Best(i));
    PD(:,i)=Aero_Results.PD{i}(:,ID_Best(i));
    OF(:,i)=Aero_Results.OF{i}(:,ID_Best(i));
    LDR(:,i)=Aero_Results.LDR{i}(:,ID_Best(i));
end
r=Aero_Results.R;
Aero_Results.L=L;
Aero_Results.T=T;
Aero_Results.CL=CL;
Aero_Results.CD=CD;
Aero_Results.CP=CP;
Aero_Results.Re=Re;
Aero_Results.PD=PD;
Aero_Results.OF=OF;
Aero_Results.LDR=LDR;
getPlot(r,L,'Chord','(m)',Lgd,shp,col,1010)
getPlot(r,T,'Twist','(^o)',Lgd,shp,col,1011)
getPlot(r,CL,'C_L',[],Lgd,shp,col,1012)
getPlot(r,CD,'C_D',[],Lgd,shp,col,1013)
getPlot(r,CP,'C_P',[],Lgd,shp,col,1014)
getPlot(r,Re,'Re','(x10^7)',Lgd,shp,col,1015)
getPlot(r,PD,'Power Distribution','(kW/m^2)',Lgd,shp,col,1016)
getPlot(r,OF,'MOF',[],Lgd,shp,col,1017)
getPlot(r,CL./CD,'C_L/C_D',[],Lgd,shp,col,1018)

Result=matfile('MB.mat','Writable',true);
Result.Optimum_Aero_Results=Aero_Results;
matfile('MB.mat','Writable',false);