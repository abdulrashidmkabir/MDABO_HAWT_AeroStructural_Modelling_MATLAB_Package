function getPlot(r,T,Name,Unit,Lgd,shp,col,id)
figure(id)
k=0;
shp1={'-' , '--' , ':' , '-.' ,'-' , '--' };
for i=1:6
    k=k+1;
    if size(T,1)==1
       t=zeros(1,6);
       t(k)=T(k);
       bar(t,'LineStyle',shp1{k},'FaceColor',col{i},'EdgeColor',col{7-i})
    else
    plot(r(:,k)/max(r(:,k)),T(:,k),shp{i},'linewidth',1.5,'MarkerSize',4,'MarkerFaceColor',col{i})
    end
    hold on
end
grid on
ylabel([Name,' ',Unit])
if size(T,1)==1
    xlabel('Case Number')
else
xlabel('Blade Length (r/R)')
xlim([0 1.1])
end
legend(Lgd)