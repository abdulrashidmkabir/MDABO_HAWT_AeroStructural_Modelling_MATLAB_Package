function PLOT_RESULTS(Case,CASE1,CASE2,lg)
global Aero_Results
col={'g','m','r','k','y','b','m','g','b','c','r','y'};
shp={'->g','-<m','-^r','-ok','-sy','-xb','-<m','->g','-sb','-*c','-^r','-+y'};
% Lgd={'LR_c_h + filters','f_3^A^e + filters','f_4^A^e + filters','MOF_b_l_a_d_e^A^e^r^o + filters','LR_c_h','f_3^A^e','f_4^A^e','MOF_b_l_a_d_e^A^e^r^o'};
Lgd={'M1','M2','M3','M4','M5','M6','M7','M8'}; % Methods
% M1='LDR + (LR & Filter)'
% M2='(PD + LDR)+Filter'
% M3='(TA + LDR)+Filter'
% M4='MOF + Filter'
% M1='LDR + LR'
% M2='PD + LDR'
% M3='TA + LDR'
% M4='MOF'
k=0;
Aero_Results.R(1:34,Case)=CASE1{1,Case}.Inputs.r;
root=CASE1{1,Case}.root;
tip=CASE1{1,Case}.tip;
r=CASE1{1,Case}.Inputs.r;
for i=[1,3,4,6]
    k=k+1;
    % L00(:,k)=mean(CASE1{i,Case}.l(:,2:end),2);
    L(:,k)=chordFilter(mean(CASE1{i,Case}.l(:,2:end),2),root);
    L0=aeroChord(r/max(r),max(L(:,k)),1,1);
    L0(root:end)=min(L(:,k))+(max(L(:,k))-min(L(:,k)))*(L0(root:end)-min(L0))/(max(L0)-min(L0));
    L0(1:root)=L(1,k)+(L(root,k)-L(1,k))*(L0(1:root)-L0(1))/(L0(root)-L0(1));
    T0=90-mean(CASE1{i,Case}.gamma(:,2:end),2);
    T(:,k)=aeroTwist(r/max(r),max(T0(root:end)),1,1).*L0./L(:,k);
    CL(:,k)=abs(mean(CASE1{i,Case}.Cl(:,2:end),2));
    CD(:,k)=mean(CASE1{i,Case}.Cd(:,2:end),2);
    CP(:,k)=mean(CASE1{i,Case}.Cp_trap(:,2:end),2);
    Re(:,k)=mean(CASE1{i,Case}.Re(:,2:end),2);
    PD(:,k)=mean(CASE1{i,Case}.P_trap(:,2:end),2)./mean(CASE1{i,Case}.Area_surf(:,2:end),2);
    OF(:,k)=mean(CASE1{i,Case}.OF(:,2:end),2);
    OF(:,k)=OF(:,k).*PD(:,k)/max(PD(:,k));
end
for i=[1,3,4,6]
    k=k+1;
    % L00(:,k)=mean(CASE2{i,Case}.l(:,2:end),2);
    L(:,k)=chordFilter(mean(CASE2{i,Case}.l(:,2:end),2),root);
    L0=aeroChord(r/max(r),max(L(:,k)),1,1);
    L0(root:end)=min(L(:,k))+(max(L(:,k))-min(L(:,k)))*(L0(root:end)-min(L0))/(max(L0)-min(L0));
    L0(1:root)=L(1,k)+(L(root,k)-L(1,k))*(L0(1:root)-L0(1))/(L0(root)-L0(1));
    T0=90-mean(CASE2{i,Case}.gamma(:,2:end),2);
    T(:,k)=aeroTwist(r/max(r),max(T0(root:end)),1,1).*L0./L(:,k);
    CL(:,k)=abs(mean(CASE2{i,Case}.Cl(:,2:end),2));
    CD(:,k)=mean(CASE2{i,Case}.Cd(:,2:end),2);
    CP(:,k)=mean(CASE2{i,Case}.Cp_trap(:,2:end),2);
    Re(:,k)=mean(CASE2{i,Case}.Re(:,2:end),2);
    PD(:,k)=mean(CASE2{i,Case}.P_trap(:,2:end),2)./mean(CASE2{i,Case}.Area_surf(:,2:end),2);
    OF(:,k)=mean(CASE2{i,Case}.OF(:,2:end),2);
    OF(:,k)=OF(:,k).*PD(:,k)/max(PD(:,k));
end
L0=L(root,:);
Lmin=min(L(1,:));
L1=L(1,:);
for j=1:length(r)
    if j<=(root-1)
    L(j,:)=Lmin+(L(j,:)-L1).*(L0-Lmin)./(L(root-1,:)-L1);
    end
    T(j,:)=min([T(j,:);T(1,:)],[],1);
end

id=1000;
getFigure(r,L,'Chord','(m)',Lgd,shp,col,Case,1,34,id+1,lg,'L')
getFigure(r,T,'Twist','(^o)',Lgd,shp,col,Case,1,34,id+2,lg,'T')
getFigure(r,abs(CL),'C_L',[],Lgd,shp,col,Case,root,tip-2,id+3,lg,'CL')
getFigure(r,abs(CD),'C_D',[],Lgd,shp,col,Case,root,tip-2,id+4,lg,'CD')
getFigure(r,abs(CP),'C_P',[],Lgd,shp,col,Case,root,tip-2,id+5,lg,'CP')
getFigure(r,abs(Re/1e7),'Re','(x10^7)',Lgd,shp,col,Case,root,tip-2,id+6,lg,'Re')
getFigure(r,abs(PD),'Power Distribution','(kW/m^2)',Lgd,shp,col,Case,root,tip-2,id+7,lg,'PD')
getFigure(r,abs(OF),'fitness',[],Lgd,shp,col,Case,root,tip-2,id+8,lg,'OF')
getFigure(r,abs(CL./CD),'C_L/C_D',[],Lgd,shp,col,Case,root,tip-2,id+9,lg,'LDR')
end
function getFigure(r,T,Name,Unit,Lgd,shp,col,Case,x,y,id,lg,ID)
global Aero_Results
N=size(r,1);
T0=T;
if size(T,1)>1
    T(1:(x-1),:)=nan;
    for i=y+1:N
        for j=1:size(T,2)
            T1=T(i-2,j);
            T2=T(i-1,j);
            r1=r(i-2);
            r2=r(i-1);
            m=((T1-T2)/(r1-r2));
            T3=(r(i)-r2)*m+T2;
            T(i,j)=(1-1/r(i))*T3+T0(i,j)/r(i);
        end
    end
end
Aero_Results.(ID)=[Aero_Results.(ID);{T}];
C=[1,3,5,2,4,6];
figure(id)
subplot(3,2,C(Case))
k=0;
shp1={'-' , '--' , ':' , '-.' ,'-' , '--' , ':' , '-.'};
for i=[1,3,4,6,[1,3,4,6]+6]
    k=k+1;
    if size(T,1)==1
       t=zeros(1,8);
       t(k)=T(k);
       bar(t,'LineStyle',shp1{k},'FaceColor',col{i},'EdgeColor',col{13-i})
    else
    plot(r,T(:,k),shp{i},'linewidth',1,'MarkerSize',3,'MarkerFaceColor',col{i})
    end
    hold on
end
grid on
ylabel([Name,' ',Unit])
if size(T,1)==1
    xlabel('Scenario Number')
else
xlabel('Blade Length (m)')
xlim([0 1.1*max(r)])
end
if lg==1
legend(Lgd)
end
title(['Case-',num2str(Case)])
end