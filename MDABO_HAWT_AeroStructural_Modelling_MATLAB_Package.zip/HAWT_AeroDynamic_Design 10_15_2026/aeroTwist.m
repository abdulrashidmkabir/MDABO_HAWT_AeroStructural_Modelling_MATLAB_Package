function T=aeroTwist(r,T_rated,exponent,exponent1)
if nargin==1
    T_rated=1;
    exponent=1;
    exponent1=1;
elseif nargin==2
    exponent=1;
    exponent1=1;
elseif nargin==3
    exponent1=1;
end
r=reshape(r,numel(r),1);
r=r.^exponent;
T=r;
for z=1:numel(r)
    if r(z)>=0.143
        w=[-586.244	1775.095	-2120.569	1260.579	-383.002	52.258	-0.439	0.343];
        H=(1-r(z)).^(8:-1:1);
        T(z)=H*w';
    else
        T(z)=1;
    end
    % T(z)=max(min(T(z),1),0);
end
T=((T-min(T))./(max(T)-min(T))).^exponent1;
T=T.*T_rated;
end
