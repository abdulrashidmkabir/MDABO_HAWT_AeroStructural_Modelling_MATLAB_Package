function L=chordFilter(L0,root)
L=L0;
for i=1:size(L0,2)
    l0=L0(:,i);
    l_tip=min(l0);
    if nargin==1
        id=find(l0==max(l0),1);
    else
        id=root;
    end
    l=Filter(l0,id);
    id=find(l==max(l),1);
    maxl=l(id);
    l(id:end)=l_tip+(maxl-l_tip)*(l(id:end)-min(l))/(max(l)-min(l));
    l(1:find(l==max(l),1))=l0(1:find(l==max(l),1));
    l(end)=l0(end);
    id=max(find(diff(l)==max(diff(l)),1),id)-1;
    l(1:id)=l(1:id)*l(id+2)/(max(l(1:id)));
    l(id+1)=(l(id)+l(id+2))/2;
    l=l*max(l0)/max(l);
    L(:,i)=l;

end
end
function l=Filter(l,id0)
    id=find(diff(l)==max(diff(l)),1)+1;
    id=min(id,id0);
    for j=3:numel(l)
            del0=(l(j-1)-l(j-2));
            del=(l(j)-l(j-1));
        if j<id
            if del<del0
                l(j)=del0+l(j-1);
            end
        elseif j>id
            if del>del0
               l(j)=del0+l(j-1);
            end
        end
    end
end
