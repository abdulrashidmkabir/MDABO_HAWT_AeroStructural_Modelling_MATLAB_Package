function C=aeroChord(r,C_rated,exponent,exponent1)
if nargin==1
    C_rated=1;
    exponent=1;
    exponent1=1;
elseif nargin==2
    exponent=1;
    exponent1=1;
elseif nargin==3
    exponent1=1;
end
r=reshape(r,numel(r),1);
r=r.^exponent;
r(r>0.99)=0.99;
C=Evalmodel(r);
C=(C/max(C)).^exponent1;
C=C.*C_rated;
end
function C=Evalmodel(r)
C=r;
for z=1:numel(r)
    if r(z)>=0.195
        w=[-1226.381	4369.154	-6503.597	5247.198...
        	-2492.570	709.637	-117.929	11.311];
    else
        w=[36.93271	-97.02373	81.96216	-21.12735];
    end
    H=(1-r(z)).^(numel(w):-1:1);
    C(z)=H*w';
end
end