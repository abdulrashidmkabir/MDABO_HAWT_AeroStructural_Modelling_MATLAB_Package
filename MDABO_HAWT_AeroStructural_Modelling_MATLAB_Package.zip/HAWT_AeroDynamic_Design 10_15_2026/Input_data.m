function Inputs=Input_data(D,c1)
global Blade_Index
if nargin==0
    D=200;
    c1=12;
elseif nargin==1
    c1=12;
end
if isempty(Blade_Index)
    Blade_Index=0;
end
Blade_Index=Blade_Index+1;
Inputs=struct;
%% DATA INPUT
Inputs.blade.name=['Case_',num2str(Blade_Index),'_'];
Inputs.blade.folder = 'Standard Profiles'; % Or Use 'S814_825_826_interpolated_38' Intead;
[Inputs.AirfoilNames,Inputs.AirfoilTickness,Inputs.coordinates_profile,Inputs.AFI,AFI0]=get_airfoil_names(Inputs.blade.folder);
[Inputs.minAFI,Inputs.maxAFI]=deal(min(Inputs.AFI),max(Inputs.AFI));
[Num,Str]=SampleInput;
Num(:,3)=Num(:,3)*0.5*D/(13.1165*max(Num(:,3)));
Inputs.blade.sections = numel(Num(:,1));
Inputs.blade.profiles = Str(:,1);
for a=1:Inputs.blade.sections
    for b=1:numel(Inputs.AirfoilNames)
        if strcmp(Inputs.blade.profiles{a},Inputs.AirfoilNames{b})
            Inputs.blade.chord(a,1:4)=AFI0(b,1:4);
        end
    end
end

Inputs.Population_of_Grey_Wolves=2;
Inputs.Dimension_of_Grey_Wolves=Inputs.blade.sections;
Inputs.Max_Grey_Wolves_search_trials=2;

Inputs.Nbl = 3; %number of blades
Inputs.D = D; %diameter [m]
Inputs.r = Inputs.D*0.5*Num(:,1); %[m]
Inputs.lambda = 7; % tip-speed ratio
Inputs.efficiency = 1; %Mechanical and electrical wind turbine efficiency

Inputs.a = 0.275+0*Num(:,1); %linear induction factor, a = 1/3 for ideal conditions (this code will 
                  %correct the drag coefficient and the conditions won't be ideal anymore,
                  %however the induction factor will be still near 1/3)
Inputs.a_=0*Num(:,1); % Angular induction factor
Inputs.c1 = c1; %undisturbed wind speed [m/s]
Inputs.omega = 2*Inputs.lambda*Inputs.c1/Inputs.D; %rotation speed [rad/s]

Inputs.r_R = 0.1; %external radius / internal radius ratio (r / R)

Inputs.toll = 0.001; %tollerance on the chord increase [m] (we suggest to use 0.0001 for a good result)
Inputs.maxiter =8; %number of max iterations on the chord
Inputs.max_errors=9;

%Air features
Inputs.air.gamma = 1.4; % gamma = Cp / Cv
Inputs.air.R = 287; %gas constant
Inputs.air.T = 273.15 + 15; %air temperature [K]
Inputs.air.rho = 1.1162; %air density [kg/m^3]
Inputs.air.mu = 1.75e-5; %air viscosity [kg * s / m]

Inputs.visibility_Xfoil = false;
%false = do not show the XFoil window
%true = show the XFoil window

%angle of attack
Inputs.twist_max=13.308; %chord twist on the first section (hub) [m]
Inputs.twist=aeroTwist(Num(:,1),Inputs.twist_max);
Inputs.alpha.start = 0; %start value of the angle of attack
Inputs.alpha.finish = 20;  %finish value of the angle of attack
Inputs.alpha.cycle_1 = 1; %step of the first cycle (we suggest to use 1 as step)
Inputs.alpha.cycle_2 = 0.2; %step of the second cycle: this value must be a submultiple
        %of the first cycle step (we suggest to use one of the following 
        %values: 0.1, 0.2, 0.25)
        
%chord dimension for the first iterative cycle
AR_threshold=13.1165; %15; % 10;
Inputs.l_0_max = 0.5*Inputs.D/AR_threshold; %chord dimension on the first section (hub) [m]
Inputs.l_0_min = 0.1; %chord dimension on the last section (tip) [m]

%% INPUT DATA PREPROCESSING
Inputs.c2 = (1-Inputs.a)*Inputs.c1; %wind speed at the disk actuator (at the wind turbine) [m/s]
Inputs.l=Inputs.l_0_min+aeroChord(Num(:,1),Inputs.l_0_max-Inputs.l_0_min);
Inputs.u = (Inputs.a_+1).*Inputs.omega.*Inputs.r; %peripheral speed [m/s] 
Inputs.w = sqrt(Inputs.u.^2 + Inputs.c2.^2); %relative wind speed [m/s]
Inputs.Ma = Inputs.w/(sqrt(Inputs.air.gamma*Inputs.air.R*Inputs.air.T)); %Mach number
Inputs.beta = atan(Inputs.u./Inputs.c2); %relative wind angle [rad]
Inputs.beta_deg = Inputs.beta*180/pi; %relative wind angle [deg]
end






