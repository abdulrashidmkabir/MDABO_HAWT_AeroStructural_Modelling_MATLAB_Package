%%  The main function file is the "RUN_get_Results.m".
%% The following ".m" function files are included.
%  To run the main file, a model bank "MB.m" must be available, 
%  and can be obtained via the HAWT_AeroDynamic_Design simulation 
%  Software Package. 
RUN_get_Results.m
aeroChord.m                  
aeroTwist.m                  
MB.mat                       
chordFilter.m                
Organize_and_Plot_Results.m  
getPlot.m                    
smooth.m                                
Save_Results.m  