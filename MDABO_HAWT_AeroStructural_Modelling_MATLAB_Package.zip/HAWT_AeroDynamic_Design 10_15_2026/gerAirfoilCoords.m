function [xy,Name,AFI,AFI0] = gerAirfoilCoords(filename)
if isnumeric(filename)
 % {Y_upper,Th_y_upper,Y_lower,Th_y_lower,Area_upper,Area_lower,Area_mean}
if (numel(filename)==7) && range(filename)<1
    AFI=filename;
    xy=generateAirfoilCoords([],AFI);
    xy=Interpolation0(xy{1}) ;
else
    xy=filename;
    AFI=getAirfoilInfos0(filename);
    xy=Interpolation0(xy) ;
end

Name=[];
for a=1:numel(AFI)
    n=num2str(fix(AFI(a)*1000));
    Name=[Name,n(1:2)];
end
Name=[Name,'.dat'];
else
if nargin == 0
    %Empty airfoil...
    return
end
%% Load airfoil from file, using the standard Eppler format

%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
% open the airfoil file
    if strcmp(filename(end-2:end),'dat')
        fid = fopen(filename);
        Header = fgetl(fid);
        tmp=textscan(Header, '%f%f','MultipleDelimsAsOne',true);
        if isempty(tmp{1})
            HasHeader=1;
            Name = strtrim(Header);
        else
            HasHeader=0;
            [~,f,~]=fileparts(filename);
            Name = f;
        end
        frewind(fid);
        Coordinates = textscan(fid, '%f%f','HeaderLines',HasHeader,'MultipleDelimsAsOne',true);
        fclose(fid);

        %Separate upper and lower coordinates
        X=Coordinates{1};
        Y=Coordinates{2};
        xy=[X,Y];
    else
        [~,Name,~]=fileparts(filename);
        fid = fopen(filename, 'r');
        if fid == -1
            error(['ERROR: Could not locate and open file ' filename]);
        end
        
        % skip the header lines
        for j = 1:4
            fgetl(fid);
        end
    
        % read the table of x-y coordinates
        xy = fscanf(fid, '%f %f', [2, Inf]);
        
        % close the airfoil file
        fclose(fid);
        
        % transpose, so the xy data matches the orientation of the file
        xy = xy';
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[AFI,AFI0]=getAirfoilInfos0(xy);
xy=Interpolation0(xy) ;
end
end
function [AFI,AFI0]=getAirfoilInfos0(coordinates_profile)
AFinfo0=[0.499700000000000	0.501407692888797	-0.499700000000000	-0.501401294762412	0.606857019512360	0.606536599356241	0.329380894049805];
coordinates_profile=Interpolation0(coordinates_profile);
x_profile = coordinates_profile(:,1);
y_profile = coordinates_profile(:,2);
[u,iu]=max(y_profile);
Y_upper=u;
Th_y_upper=atan(u/x_profile(iu))*2/pi;
[l,il]=min(y_profile);
Y_lower=l;
Th_y_lower=atan(l/x_profile(il))*2/pi;
dx=diff(coordinates_profile(:,1));
k=find(sign(dx)~=sign(dx(1)),1);
U=coordinates_profile(1:k,:);
L=coordinates_profile(k:end,:);
UL=(U+L)/2;
au=sqrt(polyarea(U(:,1),U(:,2)));
al=sqrt(polyarea(L(:,1),L(:,2)));
aul=sqrt(polyarea(UL(:,1),UL(:,2)));
Area_upper=au;
Area_lower=al;
Area_mean=aul;
AFI0=[Y_upper,Th_y_upper,Y_lower,Th_y_lower,Area_upper,Area_lower,Area_mean];
AFI=AFI0./AFinfo0;
% AFI=round(AFinfo,3);
end
function xy=Interpolation0(xy) 
z=[0.997501000000000	0.977519000000000	0.957541000000000	0.937563000000000	0.917585000000000	0.897606000000000	0.877624000000000	0.857641000000000	0.837655000000000	0.817667000000000	0.797676000000000	0.777682000000000	0.757685000000000	0.737686000000000	0.717684000000000	0.697679000000000	0.677672000000000	0.657662000000000	0.637649000000000	0.617633000000000	0.597616000000000	0.577596000000000	0.557574000000000	0.537549000000000	0.517523000000000	0.497495000000000	0.477466000000000	0.457435000000000	0.437403000000000	0.417369000000000	0.397335000000000	0.377300000000000	0.357265000000000	0.337230000000000	0.317195000000000	0.297161000000000	0.277127000000000	0.257094000000000	0.237063000000000	0.217032000000000	0.197004000000000	0.176978000000000	0.156954000000000	0.136935000000000	0.116919000000000	0.0969100000000000	0.0919080000000000	0.0869080000000000	0.0819080000000000	0.0769080000000000	0.0719090000000000	0.0669120000000000	0.0619150000000000	0.0569190000000000	0.0519250000000000	0.0469320000000000	0.0419400000000000	0.0369510000000000	0.0319640000000000	0.0269800000000000	0.0220000000000000	0.0170250000000000	0.0120600000000000	0.0115640000000000	0.0110680000000000	0.0105730000000000	0.0100780000000000	0.00958300000000000	0.00908800000000000	0.00859400000000000	0.00810000000000000	0.00760600000000000	0.00711300000000000	0.00662000000000000	0.00612800000000000	0.00563600000000000	0.00514500000000000	0.00465400000000000	0.00417200000000000	0.00369000000000000	0.00320900000000000	0.00273000000000000	0.00225300000000000	0.00177800000000000	0.00130800000000000	0.000842000000000000	0.000388000000000000
   0.000612000000000000	0.00115800000000000	0.00169200000000000	0.00222200000000000	0.00274700000000000	0.00327000000000000	0.00379100000000000	0.00431000000000000	0.00482800000000000	0.00534600000000000	0.00585500000000000	0.00636400000000000	0.00687200000000000	0.00738000000000000	0.00788700000000000	0.00839400000000000	0.00890000000000000	0.00940600000000000	0.00991200000000000	0.0104170000000000	0.0109220000000000	0.0114270000000000	0.0119320000000000	0.0124360000000000	0.0129400000000000	0.0179750000000000	0.0230000000000000	0.0280200000000000	0.0330360000000000	0.0380490000000000	0.0430600000000000	0.0480680000000000	0.0530750000000000	0.0580810000000000	0.0630850000000000	0.0680880000000000	0.0730910000000000	0.0780920000000000	0.0830920000000000	0.0880920000000000	0.0930920000000000	0.0980900000000000	0.118081000000000	0.138065000000000	0.158046000000000	0.178022000000000	0.197996000000000	0.217968000000000	0.237937000000000	0.257906000000000	0.277873000000000	0.297839000000000	0.317805000000000	0.337770000000000	0.357735000000000	0.377700000000000	0.397665000000000	0.417631000000000	0.437597000000000	0.457565000000000	0.477534000000000	0.497505000000000	0.517477000000000	0.537451000000000	0.557426000000000	0.577404000000000	0.597384000000000	0.617367000000000	0.637351000000000	0.657338000000000	0.677328000000000	0.697321000000000	0.717316000000000	0.737314000000000	0.757315000000000	0.777318000000000	0.797324000000000	0.817333000000000	0.837345000000000	0.857359000000000	0.877376000000000	0.897394000000000	0.917415000000000	0.937437000000000	0.957459000000000	0.977481000000000	0.997499000000000] ;                   
%% Interpolation of Airfoil Coodinates
        dx=diff(xy(:,1));
        k=find(sign(dx)~=sign(dx(1)),1);
        [x1,x2]=deal(z(1,:)',z(2,:)');
        xy_up=xy(1:k,:);
        [~,id]=unique(xy_up(:,1));
        xy_up=xy_up(id,:);
        y1=interp1(xy_up(:,1),xy_up(:,2),x1);
        xy_down=[xy(k:end,:);[0,0]];
        [~,id]=unique(xy_down(:,1));
        xy_down=xy_down(id,:);
        y2=interp1(xy_down(:,1),xy_down(:,2),x2);
        xy=[[x1,y1];0,0;[x2,y2]];
        for s=1:size(xy,1)
            if isnan(xy(s,2))
                k=[max(s-1,1),min(s+1,size(xy,1))];
                k=k(k~=s);
                xy(s,2)=mean(xy(s,1)*(xy(k,2)+eps)./(xy(k,1)+eps));
            end
        end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
