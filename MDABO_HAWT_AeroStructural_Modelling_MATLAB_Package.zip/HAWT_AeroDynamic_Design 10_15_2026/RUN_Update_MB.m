Scenario_ID=[ ];
% Kindly check the content Model Bank 'MB.mat' and Uncomment the existing 
% scenarios. Example: the first four scenarios are already simulated 
Scenario_ID0=[          % Note Disable/Comment Scenario IDs to simulate them
     % 1     0     1
     % 1     0     2
     % 1     0     3
     % 1     0     4
     % 1     0     5
     % 1     0     6
     % 1     1     1
     % 1     1     2
     % 1     1     3
     % 1     1     4
     % 1     1     5
     % 1     1     6
     % 2     0     1
     % 2     0     2
     % 2     0     3
     % 2     0     4
     % 2     0     5
     % 2     0     6
     % 2     1     1
     % 2     1     2
     % 2     1     3
     % 2     1     4
     % 2     1     5
     % 2     1     6
     % 3     0     1
     % 3     0     2
     % 3     0     3
     % 3     0     4
     % 3     0     5
     % 3     0     6
     % 3     1     1
     % 3     1     2
     % 3     1     3
     % 3     1     4
     % 3     1     5
     % 3     1     6
     % 4     0     1
     % 4     0     2
     % 4     0     3
     % 4     0     4
     % 4     0     5
     % 4     0     6
     % 4     1     1
     % 4     1     2
     % 4     1     3
     % 4     1     4
     % 4     1     5
     % 4     1     6
     % 5     0     1
     % 5     0     2
     % 5     0     3
     % 5     0     4
     % 5     0     5
     % 5     0     6
     % 5     1     1
     % 5     1     2
     % 5     1     3
     % 5     1     4
     % 5     1     5
     % 5     1     6
     % 6     0     1
     % 6     0     2
     % 6     0     3
     % 6     0     4
     % 6     0     5
     % 6     0     6
     % 6     1     1
     % 6     1     2
     % 6     1     3
     % 6     1     4
     % 6     1     5
     % 6     1     6
     ];
c=0;
k=0;
k1=0;
for c1=[12,7.5]
    for D=[50,100,200]
        c=c+1;
        Inputs = Input_data(D,c1);
        k=0;
        for of=0:5
            k=k+1;
            Inputs.blade.name=['Case_',num2str(c),'0',num2str(k),'_'];
            if ~isempty(Scenario_ID0)
            if min(sum(abs([c,0,k]-Scenario_ID0),2))~=0
                Case_1b=Design_HAWT_Blade(Inputs,'NO',of);
            end
            else
                Case_1b=Design_HAWT_Blade(Inputs,'NO',of);
            end
            disp(['... Designing HAWT ',Inputs.blade.name])
            Scenario_ID=[Scenario_ID;[c,0,k]]
        end
        k1=0;
        for of=0:5
            k1=k1+1;
            Inputs.blade.name=['Case_',num2str(c),'1',num2str(k1),'_'];
            if ~isempty(Scenario_ID0)
            if min(sum(abs([c,1,k1]-Scenario_ID0),2))~=0
                 Case_1a=Design_HAWT_Blade(Inputs,'YES',of);
            end
            else
                Case_1a=Design_HAWT_Blade(Inputs,'YES',of);
            end
            disp(['... Designing HAWT ',Inputs.blade.name])
            Scenario_ID=[Scenario_ID;[c,1,k1]]
        end
    end
end