function [airfoils,dy,xy,AFI,AFI0]=get_airfoil_names(airfoil_folder)
    fun=@gerAirfoilCoords;
    cd(airfoil_folder)
    files=dir('*.prof');
    airfoils={files(~[files.isdir]).name}';
    files=dir('*.dat');
    airfoils=[airfoils;{files(~[files.isdir]).name}'];
    for k=1:numel(airfoils)
        [xy{k,1},~,AFI(k,:),AFI0(k,:)] = fun(airfoils{k});
        dy(k,1)=range(xy{k,1}(:,2));
    end
%     xy1 = fun('DU_0405.prof');
%         dy1=range(xy1(:,2))
% dgfhg
    cd ..\
end