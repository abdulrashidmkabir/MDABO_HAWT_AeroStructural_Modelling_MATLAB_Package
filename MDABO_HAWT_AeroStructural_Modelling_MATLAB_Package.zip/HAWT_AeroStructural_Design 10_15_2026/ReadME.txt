>>> Simply RUN_CoBlade.m after configuring and preparing 
         the Input-Dataset in the following Data folders
1.  Laminate_Data                 
2.  Material_Data           
3.  Airfoil_Data       
4.  Optimization_Data
5.  Input_data
  
>>> The subfunctions used by the CoBlade Structural 
      Analysis software are stored in the following         
1.  BModes                        
2.  Source  

>>> Finally, the Ouput Results are stored in the following folders            
1.  Output_Data        
2.  Output_Figures 

>>> Lastly, other relevant result organization functions are stord 
    in the followinf Folder.
 1. Others     

