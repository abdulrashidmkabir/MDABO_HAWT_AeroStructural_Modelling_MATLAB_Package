function [Iflap Iedge angFlap] = principalValues(Ix, Iy, Ixy)

a       = (Iy + Ix)./2;
b       = sqrt( ((Iy - Ix)./2).^2 + Ixy.^2 );
Iflap   = a - b;
Iedge   = a + b;
angFlap = (1/2) .* atan(-2.*Ixy ./ (Ix - Iy)) .* (180/pi);

end % function principalValues
