function [state,options] = psoplotscores(options,state,flag)
% Plots the best and mean scores of particle swarm.

set(0, 'CurrentFigure', state.hfigure)

if strcmp(flag,'init')
    set(gca,'NextPlot','replacechildren',...
        'XLabel',xlabel('Scores'),...
        'YLabel',ylabel('Number of inidividuals'))
end

notinf   = isfinite(state.Score);
[n,bins] = hist(state.Score(notinf));
bar(bins,n,'Tag','scorehistogram','FaceColor',[0.1 0.1 0.5])