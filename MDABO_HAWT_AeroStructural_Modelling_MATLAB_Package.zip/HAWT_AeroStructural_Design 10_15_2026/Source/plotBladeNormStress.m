function plotBladeNormStress(iSIM, SIM, BLADE, WEB, OUT, Panel, NormS)

figTitle = [SIM.case{iSIM} ' beam normal stress'];
fig = figure('name', figTitle, ...
             'color', 'white', ...
             'units','normalized',...
             'outerposition',[0.1 0.1 0.8 0.8]);

convStress = 1 / 1e6;  	% conversion factor for stresses

for i = 1:BLADE.NUM_SEC
    % create a patch for the polygons of the top surface
    for n = 1:Panel(i).Top.nPanels
        x = Panel(i).Top.x{n};
        y = Panel(i).Top.y{n};
        z = Panel(i).Top.z{n};
        c = NormS(i).Top.stress_zz{n} .* convStress;
        patch(z, x, y, c, 'LineWidth', 0.01) 
    end
    
    % create a patch for the polygons of the bottom surface
    for n = 1:Panel(i).Bot.nPanels
        x = Panel(i).Bot.x{n};
        y = Panel(i).Bot.y{n};
        z = Panel(i).Bot.z{n};
        c = NormS(i).Bot.stress_zz{n} .* convStress;
        patch(z, x, y, c, 'LineWidth', 0.01) 
    end
    
    % create a patch for the polygons of the shear webs
    for n = 1:WEB.nWebs(i)
        x = Panel(i).Web.x{n};
        y = Panel(i).Web.y{n};
        z = Panel(i).Web.z{n};
        c = NormS(i).Web.stress_zz{n} .* convStress;
        patch(z, x, y, c, 'LineWidth', 0.01)    
    end
    
end

xlabel('z (m)')
ylabel('x (m)')
zlabel('y (m)')
cb = colorbar('location','NorthOutside');
set(get(cb,'xlabel'), 'String', 'normal stress, \sigma_{zz} (MPa)');
view(50,20)
axis image
alpha(0.75)

set(fig, 'renderer', 'opengl')

if OUT.SAVE_PLOTS
    cd(SIM.outputfigurefilesDir)
    savePlots(fig, figTitle, OUT.SAVE_FIG_FMT); cd ..\
end

end % function plotBladeNormStress

