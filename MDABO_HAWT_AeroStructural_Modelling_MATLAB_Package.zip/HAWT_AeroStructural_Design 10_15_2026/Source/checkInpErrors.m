function checkInpErrors(ANLS,OPT,ENV,BLADE,WEB)

if ANLS.N_MODES < 0 || ~mod(ANLS.N_MODES,1) == 0
    error('ERROR: N_MODES must be a positive integer, or equal to 0.')
end

if ANLS.N_MODES > 0 && exist(fullfile([pwd '\BModes'],'BModes.exe'),'file') ~= 2
    fprintf(1,'Could not locate BModes.exe\n'); 
    fprintf(1,'Either set N_MODES = 0, or download the BModes v3.00.00 code from:\n');
    fprintf(1,'http://wind.nrel.gov/designcodes/preprocessors/bmodes/\n');
    error(['ERROR: could not locate BModes.exe in ' pwd '\BModes' ]);
end

if ANLS.N_ELEMS < 2 || ~mod(ANLS.N_ELEMS,1) == 0
    error('ERROR: N_ELEMS must be a positive integer, greater than or equal to 2.')
end

if OPT.PITAXIS_VAL < 0 || OPT.PITAXIS_VAL > 1
    error('ERROR: PITAXIS_VAL must be between 0 and 1.');
end

if ~mod(OPT.INB_STN,1) == 0 || ~mod(OPT.TRAN_STN,1) == 0 || ... 
   ~mod(OPT.OUB_STN,1) == 0 || ~mod(BLADE.NUM_SEC,1) == 0 
    error('ERROR: INB_STN, TRAN_STN, OUB_STN, and NUM_SEC must all be positive integers, and they must be related as follows: 1 <= INB_STN < TRAN_STN < OUB_STN <= NUM_SEC.');
end

if any(diff([OPT.INB_STN; OPT.TRAN_STN; OPT.OUB_STN]) <= 0) || OPT.INB_STN < 1 || OPT.OUB_STN > BLADE.NUM_SEC     
    error('ERROR: INB_STN, TRAN_STN, OUB_STN, and NUM_SEC must all be positive integers, and they must be related as follows: 1 <= INB_STN < TRAN_STN < OUB_STN <= NUM_SEC.');
end

if OPT.NUM_CP < 2 || OPT.NUM_CP > BLADE.NUM_SEC || ~mod(OPT.NUM_CP,1) == 0
    error('ERROR: NUM_CP must be a positive integer: 2 <= NUM_CP <= NUM_SEC.');
end

if OPT.MAX_TIP_D < 0 
    error('ERROR: MAX_TIP_D must be a positive value.');
end

if ENV.FLUID_DEN < 0 
    error('ERROR: FLUID_DEN must be a positive value.');
end

if ENV.GRAV < 0 
    error('ERROR: GRAV is expected to be a positive value.');
end

if BLADE.NUM_SEC < 2 || ~mod(BLADE.NUM_SEC,1) == 0
    error('ERROR: NUM_SEC must be an integer, greater than or equal to 2.')
end

if BLADE.BLD_LENGTH < 0 
    error('ERROR: BLD_LENGTH must be a positive value.');
end

if BLADE.HUB_RAD < 0 || BLADE.HUB_RAD >= BLADE.BLD_LENGTH
    error('ERROR: HUB_RAD must be a positive value, also HUB_RAD < BLD_LENGTH');
end

if BLADE.ROT_SPD < 0 
    error('ERROR: ROT_SPD is expected to be a positive value.');
end

if BLADE.N_AF < 4 || ~mod(BLADE.N_AF,1) == 0
    error('ERROR: N_AF must be a positive integer, and greater than or equal to 4.');
end
if numel(BLADE.zFrac) ~= BLADE.NUM_SEC
    error('ERROR: The number rows entered in the "Blade Data" section should be equal to NUM_SEC.');
end

if any(diff(BLADE.zFrac) <= 0)
    error('ERROR: The blade station data is not entered in sequential order, or duplicate stations exist.');
end

if BLADE.zFrac(1) ~= 0 || BLADE.zFrac(end) ~= 1
    error('ERROR: The first and last values of zFrac should be equal to 0 and 1, respectively.');
end

if min(min(BLADE.chord)) <= 0
    error('ERROR: The chord length must be greater than 0.');
end

if min(min(BLADE.pitAxis)) < 0 || min(min(BLADE.pitAxis)) > 1
    error('ERROR: Values for pitAxis must be between 0 and 1.');
end

if WEB.NUM_WEBS < 0 || ~mod(WEB.NUM_WEBS,1) == 0
    error('ERROR: NUM_WEBS must be an integer, greater than or equal to 0.')
end

if WEB.WEB_NODES < 3 || ~mod(WEB.WEB_NODES,1) == 0
    error('ERROR: WEB_NODES must be an integer, greater than or equal to 3.')
end

if ~OPT.OPTIMIZE
    if any(diff(WEB.webNum) <= 0) || any(~mod(WEB.webNum,1) == 0)
        error('ERROR: The web data must be entered in sequential order, webNum must be a list of monotonically increasing integers.');
    end
    if any(WEB.inbStn < 1) || any(WEB.inbStn > BLADE.NUM_SEC) || any(~mod(WEB.inbStn,1) == 0)
        error('ERROR: The values of inbStn must be integers between 1 and NUM_SEC (inclusive)');
    end
    if any(WEB.oubStn < 1) || any(WEB.oubStn > BLADE.NUM_SEC) || any(~mod(WEB.oubStn,1) == 0)
        error('ERROR: The values of oubStn must be integers between 1 and NUM_SEC (inclusive)');
    end
    if any(WEB.inbStn > WEB.oubStn)
        error('ERROR: The values of inbStn must be less than or equal to oubStn');
    end
    if any(WEB.inbChLoc < 0) || any(WEB.inbChLoc > 1) || ...
       any(WEB.oubChLoc < 0) || any(WEB.oubChLoc > 1)     
        error('ERROR: Values of inbChLoc and oubChLoc should be between 0 and 1.');
    end
end

end % function checkInpErrors

