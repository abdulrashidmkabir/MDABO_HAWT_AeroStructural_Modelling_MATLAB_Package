function NormAFcoords = readAirfoilCoordFiles(SIM, BLADE)

NormAFcoords(BLADE.NUM_SEC,1).x = [];    % preallocate structure array
NormAFcoords(BLADE.NUM_SEC,1).y = [];    % preallocate structure array
for i = 1:BLADE.NUM_SEC
    
    % open the airfoil file
    if strcmp(BLADE.afFile{i}(end-2:end),'dat')
        xy=load([SIM.airfoilDir '/' char(BLADE.afFile(i))]);
        xy(xy(:,1)<=0,:)=[];
        k=find(sum(abs(xy),2)==min(sum(abs(xy),2)),1);
        [x1,x2]=Xairfoil;
        xy_up=xy(1:k,:);
        [~,id]=unique(xy_up(:,1));
        xy_up=[xy_up(id,:);[0 0];[1 0]];
        y1=interp1(xy_up(:,1),xy_up(:,2),x1);
        xy_down=xy((1+k):end,:);
        [~,id]=unique(xy_down(:,1));
        xy_down=[xy_down(id,:);[0 0];[1 0]];
        y2=interp1(xy_down(:,1),xy_down(:,2),x2);
        xy=[0,0;[x1,y1];1,0;[x2,y2]];
    else
    fid = fopen([SIM.airfoilDir filesep BLADE.afFile{i}], 'r');
    if fid == -1
        error(['ERROR: Could not locate and open file ' [SIM.airfoilDir filesep BLADE.afFile{i}]]);
    end
    
    % skip the header lines
    for j = 1:4
        fgetl(fid);
    end
    
    % read the table of x-y coordinates
    xy = fscanf(fid, '%f %f', [2, Inf]);
    
    % close the airfoil file
    fclose(fid);
    
    % transpose, so the xy data matches the orientation of the file
    xy = xy';
    end
    NormAFcoords(i).x = xy(:,1);
    NormAFcoords(i).y = xy(:,2);
    
    % check for errors in the user inputs
    if length(xy) < 4
        error(['Error: In file ' BLADE.afFile{i} ' the coordinates should contain at least 4 points.']);
    end
    if xy(1,1) ~= 0 || xy(1,2) ~= 0
        error(['Error: In file ' BLADE.afFile{i} ' the leading edge coordinate is not located at (x,y) = (0,0).']);
    end
    [x_max ii] = max(xy(:,1)); 
    if x_max > 1
        error(['Error: In file ' BLADE.afFile{i} ' the maximum x-coordinate exceeds the chord boundary (it should be equal to 1).']);
    end
    x_upper = xy(1:ii,1);
    y_upper = xy(1:ii,2);
    x_lower = xy(ii:end,1);
    y_lower = xy(ii:end,2); 
    if y_upper(2) < y_lower(end)
        % note: this is not a perfect test for clockwise ordering, but I think it
        % will be sufficient given the other requirements for coordinate ordering
        error(['Error: In file ' BLADE.afFile{i} ' the coordinates are not labeled in clock-wise order.']);
    end
    if any( diff(x_upper) <= 0 )
        error(['Error: In file ' BLADE.afFile{i} ' the upper surface is not a single valued function.']);
    end
    if any( diff(x_lower) >= 0 )
        % note: we excluded the trailing edge in this check, to allow for finite thickness trailing edges
        error(['Error: In file ' BLADE.afFile{i} ' the lower surface is not a single valued function.']);
    end
      
end

end % function readAirfoilCoordFiles
function [U,L]=Xairfoil
U=[
    0.0010
    0.0041
    0.0092
    0.0164
    0.0255
    0.0365
    0.0495
    0.0643
    0.0810
    0.0993
    0.1193
    0.1408
    0.1638
    0.1883
    0.2139
    0.2408
    0.2687
    0.2976
    0.3273
    0.3577
    0.3887
    0.4202
    0.4520
    0.4840
    0.5160
    0.5480
    0.5798
    0.6113
    0.6423
    0.6727
    0.7024
    0.7313
    0.7592
    0.7861
    0.8117
    0.8362
    0.8592
    0.8807
    0.9007
    0.9190
    0.9357
    0.9505
    0.9635
    0.9745
    0.9836
    0.9908
    0.9959
    0.9990];

    L=[
    0.9990
    0.9959
    0.9908
    0.9836
    0.9745
    0.9635
    0.9505
    0.9357
    0.9190
    0.9007
    0.8807
    0.8592
    0.8362
    0.8117
    0.7861
    0.7592
    0.7313
    0.7024
    0.6727
    0.6423
    0.6113
    0.5798
    0.5480
    0.5160
    0.4840
    0.4520
    0.4202
    0.3887
    0.3577
    0.3273
    0.2976
    0.2687
    0.2408
    0.2139
    0.1883
    0.1638
    0.1408
    0.1193
    0.0993
    0.0810
    0.0643
    0.0495
    0.0365
    0.0255
    0.0164
    0.0092
    0.0041
    0.0010
    ];
end