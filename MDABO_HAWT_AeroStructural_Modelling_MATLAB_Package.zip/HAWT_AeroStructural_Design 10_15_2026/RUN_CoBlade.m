%% clear all variables and close files/figures
clear all;
close('all');
fclose('all');
format compact;

%% set the Co-Blade version
SIM.version = '1.20.00-dcs';

%% add paths to the source code
SIM.rootDir     = pwd; 
SIM.bmodesfilesDir= [SIM.rootDir filesep 'BModes'];
SIM.inputdatafilesDir= [SIM.rootDir filesep 'Input_Data'];
SIM.outputdatafilesDir= [SIM.rootDir filesep 'Output_Data'];
SIM.outputfigurefilesDir= [SIM.rootDir filesep 'Output_Figures'];
SIM.sourceDir   = [SIM.rootDir filesep 'Source'];
SIM.airfoilDir  = [SIM.rootDir filesep 'Airfoil_Data'];
SIM.materialDir = [SIM.rootDir filesep 'Material_Data'];
SIM.laminateDir = [SIM.rootDir filesep 'Laminate_Data'];
SIM.optimDir    = [SIM.rootDir filesep 'Optimization_Data'];
SIM.OthersDir=[SIM.rootDir filesep 'Others'];
% NOTE: comment out the addpath commands before compiling
addpath( SIM.sourceDir )
addpath([SIM.sourceDir filesep 'consolidator'])
addpath([SIM.sourceDir filesep 'dispCorrectionFactor'])
addpath([SIM.sourceDir filesep 'export_fig'])
addpath([SIM.sourceDir filesep 'polygeom'])
addpath([SIM.sourceDir filesep 'psopt'])

%% set debugging breakpoints
% dbstop in structOptimize.m at 453
% dbstop in structAnalysis.m at 332

%% Read the list of active input files
fid = fopen([SIM.inputdatafilesDir filesep 'Active_Input_Files.inp'], 'r');
if fid == -1
    error(['ERROR: Could not locate and open file ' [SIM.inputdatafilesDir filesep 'Active_Input_Files.inp']]);
end
inpList = textscan(fid,'%s');
fclose(fid);

SIM.inpFile = inpList{:};
nInpFiles   = numel(SIM.inpFile);
SIM.case    = cell(nInpFiles, 1);
for iSIM = 1:nInpFiles
    [pathstr SIM.case{iSIM} ext] = fileparts(SIM.inpFile{iSIM});
end

%% main loop that sequentially executes the active input files
for iSIM = 1:nInpFiles 
    fprintf(1, 'Executing case %s with Co-Blade v%s.\n', SIM.inpFile{iSIM}, SIM.version);
    
    clear ANLS OPT ENV BLADE WEB OUT MATS AF Coord % clear data structures from previous input files (don't want to accidentally keep any old values)
         [ANLS OPT ENV BLADE WEB OUT MATS AF Coord] = CoBlade_init(iSIM, SIM); 

    %% Define the laminate data, either by optimization, or read data from the laminate input files
    if OPT.OPTIMIZE

        WEB.inbStn = OPT.INB_STN .* ones(WEB.NUM_WEBS, 1);  % all the webs begin and end at blade stations INB_STN and OUB_STN
        WEB.oubStn = OPT.OUB_STN .* ones(WEB.NUM_WEBS, 1);

        % Determine the laminate data from optimization routine
        [WEB SECNODES LamData] = structOptimize(iSIM, SIM, ANLS, OPT, ENV, BLADE, WEB, AF, MATS, Coord, OUT);

    else
        % Read the pre-defined laminate data from the laminate input files
        [SECNODES LamData] = readLaminateData(SIM, BLADE, WEB, MATS);
    end

    %% execute the structural analysis
    [Panel StrProps AppLoads ResLoads Disp NormS ShearS Buckle MidPlane LaminaSS Modes] ...
     = structAnalysis(iSIM, SIM, ANLS, ENV, BLADE, WEB, MATS, LamData, AF, SECNODES, Coord);
     
    %% write output files
    if OPT.OPTIMIZE || OPT.OPT_PITAXIS
        % create a copy of the main input file, but update any parameters that were changed/created by the optimization routine                 
        if OPT.OPTIMIZE
            BLADE.strFile = cell(BLADE.NUM_SEC, 1); % overwrite this variable with the new names
            for n = 1:BLADE.NUM_SEC
                BLADE.strFile{n} = [SIM.case{iSIM} '_OPT_' num2str(n) '.lam'];
            end 
        end
        writeInpFileNewMain(iSIM, SIM, OPT, BLADE, WEB);
    end
    
    if OUT.PROPS_FILE
        writeOupFileProps(iSIM, SIM, BLADE, StrProps, OUT);
    end   

    if OUT.LOAD_DSP_FILE
        writeOupFileLoads(iSIM, SIM, BLADE, AppLoads, ResLoads, Disp, OUT);
    end

    if OUT.PANEL_FILE
        writeOupFilePanel(iSIM, SIM, BLADE, WEB, SECNODES, Panel, NormS, ShearS, Buckle, OUT);
    end

    if OUT.LAMINA_FILE
        writeOupFileLamina(iSIM, SIM, BLADE, WEB, SECNODES, Panel, Buckle, LaminaSS, OUT);
    end

    %% create output plots
    if OUT.DATA_GUI
        startDataGUI(iSIM, SIM, OPT, BLADE, WEB, AF, Panel, LaminaSS);
    end
    
    if OUT.PLOT_F_BLD || OUT.PLOT_DISP_BLD
        plotLoadsDisp(iSIM, SIM, BLADE, AF, Coord, AppLoads, Disp, StrProps, OUT)
    end

    if OUT.PLOT_YMOD
        plotBladeYModulus(iSIM, SIM, BLADE, WEB, OUT, Panel)
    end

    if OUT.PLOT_GMOD
        plotBladeGModulus(iSIM, SIM, BLADE, WEB, OUT, Panel)
    end

    if OUT.PLOT_MASS_DEN || OUT.PLOT_PRIN_ANG || OUT.PLOT_AT_STFF || ...
       OUT.PLOT_BSTFF    || OUT.PLOT_INER     || OUT.PLOT_CENTERS
        plotStructProps(iSIM, SIM, BLADE, StrProps, OUT);
    end

    if OUT.PLOT_NORMS
        plotBladeNormStress(iSIM, SIM, BLADE, WEB, OUT, Panel, NormS)
    end

    if OUT.PLOT_SHEARS
        plotBladeShearStress(iSIM, SIM, BLADE, WEB, OUT, Panel, ShearS)
    end

    if OUT.PLOT_BCRIT
        plotBladeBuckleCrit(iSIM, SIM, BLADE, WEB, OUT, Panel, Buckle)
    end

    if OUT.PLOT_E11 || OUT.PLOT_E22 || OUT.PLOT_E12
        plotLaminaStrain(iSIM, SIM, BLADE, WEB, MATS, Panel, LaminaSS, OUT)
    end

    if OUT.PLOT_S11 || OUT.PLOT_S22 || OUT.PLOT_S12
        plotLaminaStress(iSIM, SIM, BLADE, WEB, MATS, Panel, LaminaSS, OUT)
    end

    if OUT.PLOT_S11_FC || OUT.PLOT_S22_FC || OUT.PLOT_S12_FC
        plotLaminaStressFC(iSIM, SIM, BLADE, WEB, MATS, Panel, LaminaSS, OUT)
    end

    if ( OUT.PLOT_MODE_S || OUT.PLOT_MODE_D ) && ANLS.N_MODES >= 1
        plotModes(iSIM, SIM, ANLS, Modes, OUT)
    end

    if OUT.PLOT_APPLOADS || OUT.PLOT_RESLOADS
        plotLoads(iSIM, SIM, BLADE, AppLoads, ResLoads, OUT)
    end

    if OUT.PLOT_DEFLECT
        plotDeflect(iSIM, SIM, BLADE, Disp, OUT)
    end
    
    fprintf(1, 'Co-Blade v%s terminated normally for case %s. \r\n', SIM.version, SIM.inpFile{iSIM});
    
end % for iSIM = 1:nInpFiles


