function BladeInfos = getBladeInfos(BladeModel)
r=BladeModel.Inputs.r; 
l=BladeModel.l; 
beta=pi/2-BladeModel.Inputs.beta; 
w=BladeModel.Inputs.w'; 
Cd=BladeModel.Cd; 
Cl=BladeModel.Cl; 
air=BladeModel.Inputs.air; 
gamma=BladeModel.gamma; 
Profiles=BladeModel.Inputs.blade.profiles';
Nbl=BladeModel.Inputs.Nbl;

px_a=l*0;  % resultant x-axis drag force per meter
py_a=l*0;  % resultant y-axis drag force per meter
qz_a=l*0;  % resultant z-axis drag moment/torque per meter

for ii = 1:length(r)  
    j=max(ii-1,1);
    pD1=0.5*air.rho*l(ii)*Cd(ii)*w(ii)^2;
    pD0=0.5*air.rho*l(j)*Cd(j)*w(j)^2;
    pD=(pD1+pD0)/2;
    pL1=0.5*air.rho*l(ii)*Cl(ii)*w(ii)^2;
    pL0=0.5*air.rho*l(j)*Cl(j)*w(j)^2;
    pL=(pL1+pL0)/2;
    px_a(ii)=(pL*cos(beta(ii))+pD*sin(beta(ii))+pL*cos(beta(j))+pD*sin(beta(j)))/2;
    py_a(ii)=(pL*sin(beta(ii))-pD*cos(beta(ii))+pL*sin(beta(j))-pD*cos(beta(j)))/2;
    qD1=0.5*Nbl*air.rho*l(ii)*r(ii)*Cd(ii)*w(ii)^2;
    qD0=0.5*Nbl*air.rho*l(j)*r(j)*Cd(j)*w(j)^2;
    qD=(qD1+qD0)/2;
    qL1=0.5*Nbl*air.rho*l(ii)*r(ii)*Cl(ii)*w(ii)^2;
    qL0=0.5*Nbl*air.rho*l(j)*r(j)*Cl(j)*w(j)^2;
    qL=(qL1+qL0)/2;
    qz_a(ii)=(qL*sin(beta(ii))-qD*cos(beta(ii))+qL*sin(beta(j))-qD*cos(beta(j)))/2 ;
end
[px_a,py_a]=deal(py_a,px_a);
% Build Input Data Table for Co-Blade
[Num,Str]=sampleInputs;
zFrac=Num(:,1);
% [r/r(end),90-gamma,Num(:,2),BladeModel.Inputs.beta_deg,BladeModel.alpha,(Num(:,2))]
aeroTwst=Interps(r/r(end),90-gamma,zFrac); 
aeroTwst=aeroTwst-aeroTwst(end);
chord=Interps(r/r(end),l,zFrac);      
pitAxis=Num(:,4);
px_a=Interps(r/r(end),px_a,zFrac);          
py_a=Interps(r/r(end),py_a,zFrac);          
qz_a=Interps(r/r(end),qz_a,zFrac);     
af_shape_file=Profiles(round(Interps(r/r(end),(1:length(Profiles))',zFrac)),1);   
int_str_file=Str(round(Interps(r/r(end),(1:length(Profiles))'*length(zFrac)/length(Profiles),zFrac)),2); 

BladeInfos=table(zFrac,aeroTwst,chord,pitAxis,px_a,py_a,qz_a,af_shape_file,int_str_file);
end
function [y]=Interps(x0,y0,x)
[~,id]=unique(x0);
x0=x0(id,:);
y0=y0(id,:);
if x0(1)>min(x)
    x0=[min(x);x0];
    y01=y0(1)+(min(x)-x0(1))*(y0(1)-y0(2))/(x0(1)-x0(2));
    y0=[y01;y0];
end
if x0(end)<max(x)
    x0=[x0;max(x)];
    y01=y0(end)+(max(x)-x0(end))*(y0(end)-y0(end-1))/(x0(end)-x0(end-1));
    y0=[y0;y01];
end
y=interp1(x0,y0,x);
end
function [Num,Str]=sampleInputs

Num=[
0.000       13.308        5.694        0.500                
0.003       13.308        5.694        0.500                
0.010       13.308        5.694        0.500             
0.022       13.308        5.772        0.499               
0.038       13.308        5.949        0.490                
0.057       13.308        6.170        0.476                 
0.078       13.308        6.418        0.461                
0.100       13.308        6.676        0.445                
0.122       13.308        6.934        0.429                 
0.143       13.308        7.184        0.412                 
0.162       13.182        7.396        0.400                 
0.178       13.053        7.545        0.391                 
0.188       12.955        7.605        0.383                 
0.195       12.900        7.624        0.380                 
0.202       12.700        7.620        0.380                 
0.210       12.500        7.611        0.379                 
0.230       11.900        7.550        0.378                 
0.260       11.000        7.430        0.377                 
0.290       10.300        7.280        0.375                 
0.340        9.500        7.020        0.375                
0.400        8.400        6.670        0.375                
0.460        7.300        6.300        0.375                 
0.520        6.100        5.910        0.375                 
0.580        5.100        5.550        0.375                 
0.633        4.214        5.227        0.375                
0.698        3.182        4.827        0.375                 
0.761        2.388        4.443        0.375                
0.819        1.701        4.090        0.375                 
0.871        1.079        3.766        0.375                
0.916        0.569        3.267        0.375                
0.952        0.236        2.542        0.375                 
0.978        0.109        1.553        0.375                
0.995        0.027        0.535        0.375                 
1.000        0.000        0.100        0.375                
    ];

Str=[
    {'Circle.prof'}            {'WindTurbineRef_1-3.lam'}
   {'Circle.prof'}            {'WindTurbineRef_1-3.lam'}
     {'Transition_0982.prof'}   {'WindTurbineRef_1-3.lam'}
    {'Transition_0939.prof'}   {'WindTurbineRef_4.lam'}
     {'Transition_0878.prof'}   {'WindTurbineRef_5.lam'}
     {'Transition_0803.prof'}   {'WindTurbineRef_6.lam'}
      {'Transition_0723.prof'}   {'WindTurbineRef_7.lam'}
     {'Transition_0645.prof'}   {'WindTurbineRef_8.lam'}
    {'Transition_0577.prof'}   {'WindTurbineRef_9.lam'}
    {'Transition_0517.prof'}   {'WindTurbineRef_10.lam'}
     {'Transition_0472.prof'}   {'WindTurbineRef_11.lam'}
    {'Transition_0437.prof'}   {'WindTurbineRef_12.lam'}
     {'Transition_0418.prof'}   {'WindTurbineRef_13.lam'}
     {'DU_0405.prof'}           {'WindTurbineRef_14.lam'}
      {'DU_0395.prof'}           {'WindTurbineRef_15.lam'}
    {'DU_0385.prof'}           {'WindTurbineRef_16.lam'}
     {'DU_0368.prof'}           {'WindTurbineRef_17.lam'}
   {'DU_0350.prof'}           {'WindTurbineRef_18.lam'}
   {'DU_0330.prof'}           {'WindTurbineRef_19.lam'}
    {'DU_0300.prof'}           {'WindTurbineRef_20.lam'}
     {'DU_0270.prof'}           {'WindTurbineRef_21.lam'}
     {'DU_0250.prof'}           {'WindTurbineRef_22.lam'}
    {'DU_0230.prof'}           {'WindTurbineRef_23.lam'}
     {'DU_0210.prof'}           {'WindTurbineRef_24.lam'}
      {'Transition_0200.prof'}   {'WindTurbineRef_25.lam'}
     {'Transition_0183.prof'}   {'WindTurbineRef_26.lam'}
      {'NACA6_0180.prof'}        {'WindTurbineRef_27.lam'}
      {'NACA6_0180.prof'}        {'WindTurbineRef_28.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_29.lam'}
    {'NACA6_0180.prof'}        {'WindTurbineRef_30.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_31.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}
    {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}
           {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}
    ];
end