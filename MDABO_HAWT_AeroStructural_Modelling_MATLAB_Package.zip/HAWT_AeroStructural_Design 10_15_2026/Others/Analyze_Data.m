close all
% [Ls,Li,inds,indi]=plot_Result_sample('l','l (m)');
% [AoAs,AoAi]=plot_Result_sample('alpha','^o');
% [TAs,TAi]=plot_Result_sample('gamma','AoA ^o');
% [CLs,CLi]=plot_Result_sample('Cl','CL');
% [CDs,CDi]=plot_Result_sample('Cd','CD');
% [LDRs,LDRi]=plot_Result_sample('LDR','CL/CD',[{CLs./CDs},{CLi./CDi}]);
% [Ps,Pi]=plot_Result_sample('P_trap','Power (W)');
% [SAs,SAi]=plot_Result_sample('Area_surf','SA (m^2)');
% [Res,Rei]=plot_Result_sample('Re','Re Number');

% Generating the 3D-Blades Using Standard Airfoils
load('Optimum_Standard_HAWTB_Model_Bank.mat')
% Optimal Standard Blades 
ID=[1,2,5,6,9];
for i=ID
    if ~isempty(Models{i})
        blade=Models{i}.Inputs.blade;
        l=Polish(Models{i}.l);
        r=Models{i}.Inputs.r;
        twist=Models{i}.gamma;
         [Xn,Yn,Zn]=get3Dblade(blade,l,r,twist,['Case ',num2str(i)]);
         % [x,y]=get2Dblade(blade,l,twist,['Case ',num2str(i)]);
    end
end
r=r';
L=getDataFor('l','Optimum_Standard_HAWTB_Model_Bank');
L=Polish(L(:,ID));
TA=getDataFor('gamma','Optimum_Standard_HAWTB_Model_Bank');
TA=TA(:,ID);
CL=getDataFor('Cl','Optimum_Standard_HAWTB_Model_Bank');
CL=CL(:,ID);
CD=getDataFor('Cd','Optimum_Standard_HAWTB_Model_Bank');
CD=CD(:,ID);
AR=getDataFor('AR','Optimum_Standard_HAWTB_Model_Bank');
AR=AR(:,ID);
CP=getDataFor('Cp_trap','Optimum_Standard_HAWTB_Model_Bank');
CP=CP(:,ID);
FMO=getDataFor('MOBJ','Optimum_Standard_HAWTB_Model_Bank');
FMO=FMO(:,ID);
T0=[CP;AR];
T1=[r,L];
T2=[r,TA];
T3=[r,CL];
T4=[r,CD];

% Generating the 3D-Blades Using Interpolated Airfoils
load('Optimum_Interpolated_HAWTB_Model_Bank.mat')
% Optimal Standard Blades 
ID=[1,2,5,9];
for i=ID
    if ~isempty(Models{i})
        blade=Models{i}.Inputs.blade;
        l=Polish(Models{i}.l);
        r=Models{i}.Inputs.r;
        twist=Models{i}.gamma;
         [Xn,Yn,Zn]=get3Dblade(blade,l,r,twist,['Case ',num2str(i)]);
         % [x,y]=get2Dblade(blade,l,twist,['Case ',num2str(i)]);
    end
end
r=r';
Li=getDataFor('l','Optimum_Interpolated_HAWTB_Model_Bank');
Li=Polish(Li(:,ID));
TAi=getDataFor('gamma','Optimum_Interpolated_HAWTB_Model_Bank');
TAi=TAi(:,ID);
CLi=getDataFor('Cl','Optimum_Interpolated_HAWTB_Model_Bank');
CLi=CLi(:,ID);
CDi=getDataFor('Cd','Optimum_Interpolated_HAWTB_Model_Bank');
CDi=CDi(:,ID);
ARi=getDataFor('AR','Optimum_Interpolated_HAWTB_Model_Bank');
ARi=ARi(:,ID);
CPi=getDataFor('Cp_trap','Optimum_Interpolated_HAWTB_Model_Bank');
CPi=CPi(:,ID);
FMOi=getDataFor('MOBJ','Optimum_Interpolated_HAWTB_Model_Bank');
FMOi=FMOi(:,ID);
T0i=[CPi;ARi];
T1i=[r,Li];
T2i=[r,TAi];
T3i=[r,CLi];
T4i=[r,CDi];

figure(199)
plot(T1(:,1),[T1(:,2:end),T1i(:,2:end)])
ylabel('l (m)')
xlabel('r (m)')
Lg=[{'Standard. Case-1'},...
       {'Standard. Case-2'},...
       {'Standard. Case-5'},...
       {'Standard. Case-6'},...
       {'Standard. Case-9'},...
       {'Interpolated. Case-1'},...
       {'Interpolated. Case-2'},...
       {'Interpolated. Case-5'},...
       {'Interpolated. Case-9'},...
    ];
legend(Lg)

figure(1991)
plot(T1(:,1),[T2(:,2:end),T2i(:,2:end)])
ylabel('TA (^o)')
xlabel('r (m)')
legend(Lg)

figure(1993)
plot(T1(:,1),[T3(:,2:end),T3i(:,2:end)])
ylabel('CL')
xlabel('r (m)')
legend(Lg)

figure(1994)
plot(T1(:,1),[T4(:,2:end),T4i(:,2:end)])
ylabel('CD')
xlabel('r (m)')
legend(Lg)
