 D=[{'Circle.prof'}            {'WindTurbineRef_1-3.lam'}
   {'Circle.prof'}            {'WindTurbineRef_1-3.lam'}
     {'Transition_0982.prof'}   {'WindTurbineRef_1-3.lam'}
    {'Transition_0939.prof'}   {'WindTurbineRef_4.lam'}
     {'Transition_0878.prof'}   {'WindTurbineRef_5.lam'}
     {'Transition_0803.prof'}   {'WindTurbineRef_6.lam'}
      {'Transition_0723.prof'}   {'WindTurbineRef_7.lam'}
     {'Transition_0645.prof'}   {'WindTurbineRef_8.lam'}
    {'Transition_0577.prof'}   {'WindTurbineRef_9.lam'}
    {'Transition_0517.prof'}   {'WindTurbineRef_10.lam'}
     {'Transition_0472.prof'}   {'WindTurbineRef_11.lam'}
    {'Transition_0437.prof'}   {'WindTurbineRef_12.lam'}
     {'Transition_0418.prof'}   {'WindTurbineRef_13.lam'}
     {'DU_0405.prof'}           {'WindTurbineRef_14.lam'}
      {'DU_0395.prof'}           {'WindTurbineRef_15.lam'}
    {'DU_0385.prof'}           {'WindTurbineRef_16.lam'}
     {'DU_0368.prof'}           {'WindTurbineRef_17.lam'}
   {'DU_0350.prof'}           {'WindTurbineRef_18.lam'}
   {'DU_0330.prof'}           {'WindTurbineRef_19.lam'}
    {'DU_0300.prof'}           {'WindTurbineRef_20.lam'}
     {'DU_0270.prof'}           {'WindTurbineRef_21.lam'}
     {'DU_0250.prof'}           {'WindTurbineRef_22.lam'}
    {'DU_0230.prof'}           {'WindTurbineRef_23.lam'}
     {'DU_0210.prof'}           {'WindTurbineRef_24.lam'}
      {'Transition_0200.prof'}   {'WindTurbineRef_25.lam'}
     {'Transition_0183.prof'}   {'WindTurbineRef_26.lam'}
      {'NACA6_0180.prof'}        {'WindTurbineRef_27.lam'}
      {'NACA6_0180.prof'}        {'WindTurbineRef_28.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_29.lam'}
    {'NACA6_0180.prof'}        {'WindTurbineRef_30.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_31.lam'}
     {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}
    {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}
           {'NACA6_0180.prof'}        {'WindTurbineRef_32-34.lam'}]

 D1=[
     {'Circle.prof'         }
    {'Circle.prof'         }
    {'Transition_0982.prof'}
    {'Transition_0939.prof'}
    {'Transition_0878.prof'}
    {'Transition_0803.prof'}
    {'Transition_0723.prof'}
    {'Transition_0645.prof'}
    {'Transition_0577.prof'}
    {'Transition_0517.prof'}
    {'Transition_0472.prof'}
    {'Transition_0437.prof'}
    {'Transition_0418.prof'}
    {'DU_0405.prof'        }
    {'DU_0395.prof'        }
    {'DU_0385.prof'        }
    {'DU_0368.prof'        }
    {'DU_0350.prof'        }
    {'DU_0330.prof'        }
    {'DU_0300.prof'        }
    {'DU_0270.prof'        }
    {'DU_0250.prof'        }
    {'DU_0230.prof'        }
    {'DU_0210.prof'        }
    {'Transition_0200.prof'}
    {'Transition_0183.prof'}
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }
    {'NACA6_0180.prof'     }];