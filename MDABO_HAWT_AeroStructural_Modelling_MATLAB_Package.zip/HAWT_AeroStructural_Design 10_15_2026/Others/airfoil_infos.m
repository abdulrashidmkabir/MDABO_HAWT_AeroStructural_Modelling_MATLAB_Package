clear all
Folder='Standard profiles';  
AirfoilNames=get_airfoil_names(Folder);
Analyis; AirfoilNames=D1;
Airfoil_. IDN=(1:numel(AirfoilNames))';
Y_upper=[];
Th_y_upper=[];
Y_lower=[];
Th_y_lower=[];
Area_upper=[];
Area_lower=[];
Area_mean=[];
figure(1004)
title('Interpolated Airfoils')
for a=1:numel(AirfoilNames)
    filename=[Folder '/' char(AirfoilNames(a))];
    [coordinates_profile{a,1},AFinfo(a,:)]=getAirfoilInfos(filename);
    if a<=34
        % subplot(5,7,a)
        plot(coordinates_profile{a,1}(:,1),coordinates_profile{a,1}(:,2),'k','LineWidth',2)
        legend(AirfoilNames{a}(1:end-4))
    end
end
[Y_upper,Th_y_upper,Y_lower,Th_y_lower,Area_upper,Area_lower,Area_mean]=deal(AFinfo(:,1),AFinfo(:,2),AFinfo(:,3),AFinfo(:,4),AFinfo(:,5),AFinfo(:,6),AFinfo(:,7));
table(Airfoil_IDN, AirfoilNames, Y_upper,Th_y_upper,Y_lower,Th_y_lower,Area_upper,Area_lower,Area_mean)