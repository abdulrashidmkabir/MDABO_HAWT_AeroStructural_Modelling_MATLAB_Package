function airfoils=get_airfoil_names(airfoil_folder)
    cd(airfoil_folder)
    files=dir('*.prof');
    airfoils={files(~[files.isdir]).name}';
    files=dir('*.dat');
    airfoils=[airfoils;{files(~[files.isdir]).name}'];
    cd ..
end